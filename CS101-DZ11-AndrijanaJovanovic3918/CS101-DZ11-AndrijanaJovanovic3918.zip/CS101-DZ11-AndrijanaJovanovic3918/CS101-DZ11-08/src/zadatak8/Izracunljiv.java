package zadatak8;

public interface Izracunljiv {
    
    public abstract double racunajCenu();
}
