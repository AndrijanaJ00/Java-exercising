/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exception;

/**
 *
 * @author Andrijana Jovanovic
 */
public class NoOperandException extends Exception{
    
    public NoOperandException() {
        super("Operand nije unet!");
    }

    public NoOperandException(String message) {
        super(message);
    }
    
}
