package zadatak8;

public class Zadatak8 {

    public static void main(String[] args) {

        ITSektor it1 = new ITSektor("IT100 sektor", 10);
        System.out.println(it1.toString());

        HRSektor hr1 = new HRSektor("HR20 sektor", 23);
        System.out.println(hr1.toString());
    }

}
